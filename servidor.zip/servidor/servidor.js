const http = require('http');
const fs = require('fs');
const path = require('path');
const { MongoClient } = require('mongodb');
const ejs = require('ejs');

// === CONFIGURAÇÕES ===
const PORTA = 1600;
const MONGO_URL = "mongodb+srv://pedrogenaro59_db_user:D4oXMJbJIwtTxlAX@cluster0.r4hgty2.mongodb.net/?appName=Cluster0";
const DB_NOME = 'blog';

// === CONEXÃO COM O MONGODB ATLAS ===
let db;

MongoClient.connect(MONGO_URL)
  .then(client => {
    console.log('Conectado ao MongoDB Atlas com sucesso.');
    db = client.db(DB_NOME);
  })
  .catch(err => {
    console.error('Erro ao conectar ao MongoDB Atlas:', err);
  });

// === SERVIDOR HTTP ===
const servidor = http.createServer(async (req, res) => {
  // --- ROTA: EXIBIR POSTS (usa blog.ejs) ---
  if (req.url === '/' || req.url === '/blog') {
    if (!db) {
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end('<h1>Banco de dados não conectado ainda.</h1>');
      return;
    }

    try {
      const posts = await db.collection('posts').find().toArray();
      const template = fs.readFileSync('./blog.ejs', 'utf8');
      const html = ejs.render(template, { posts });
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(html);
    } catch (error) {
      res.writeHead(500, { 'Content-Type': 'text/html' });
      res.end(`<h1>Erro ao carregar posts: ${error.message}</h1>`);
    }
    return;
  }

  // --- ROTA: CADASTRAR POST (recebe POST do formulário) ---
  if (req.url === '/cadastrar' && req.method === 'POST') {
    let corpo = '';
    req.on('data', chunk => corpo += chunk);
    req.on('end', async () => {
      const dados = new URLSearchParams(corpo);
      const post = {
        titulo: dados.get('titulo'),
        conteudo: dados.get('conteudo'),
        data: new Date()
      };

      try {
        await db.collection('posts').insertOne(post);
        res.writeHead(302, { Location: '/' });
        res.end();
      } catch (err) {
        res.writeHead(500, { 'Content-Type': 'text/html' });
        res.end(`<h1>Erro ao cadastrar: ${err.message}</h1>`);
      }
    });
    return;
  }

  // --- ROTA: PÁGINA DE CADASTRO ---
  if (req.url === '/cadastrar_post.html') {
    fs.readFile('./cadastrar_post.html', (err, content) => {
      if (err) {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 - Página de cadastro não encontrada</h1>');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/html' });
        res.end(content, 'utf8');
      }
    });
    return;
  }

  // --- SERVIR ARQUIVOS ESTÁTICOS (CSS, JS, etc.) ---
  const extname = path.extname(req.url).toLowerCase();
  const mimeTypes = {
    '.css': 'text/css',
    '.js': 'text/javascript',
    '.png': 'image/png',
    '.jpg': 'image/jpg'
  };

  if (mimeTypes[extname]) {
    const filePath = '.' + req.url;
    fs.readFile(filePath, (error, content) => {
      if (error) {
        res.writeHead(404);
        res.end();
      } else {
        res.writeHead(200, { 'Content-Type': mimeTypes[extname] });
        res.end(content, 'utf8');
      }
    });
    return;
  }

  // --- CASO NÃO ENCONTRE NADA ---
  res.writeHead(404, { 'Content-Type': 'text/html' });
  res.end('<h1>404 - Página não encontrada</h1>');
});

// === INICIA O SERVIDOR ===
servidor.listen(PORTA, () => {
  console.log(`Servidor rodando em http://localhost:${PORTA}`);
});
